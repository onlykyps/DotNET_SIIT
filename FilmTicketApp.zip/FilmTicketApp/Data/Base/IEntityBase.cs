﻿namespace FilmTicketApp.Data.Base
{
   public interface IEntityBase
   {
      int Id { get; set; }
   }
}
