﻿namespace FilmTicketApp.Data.Enums
{
   public enum FilmGenre
   {
      Action = 1,
      Comedy,
      Drama,
      Documentary,
      Animation
   }
}
